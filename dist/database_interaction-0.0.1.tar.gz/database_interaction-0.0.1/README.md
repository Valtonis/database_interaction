Database interaction supporting classes
